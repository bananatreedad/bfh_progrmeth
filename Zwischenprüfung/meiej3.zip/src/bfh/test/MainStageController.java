package bfh.test;

import java.util.Observable;
import java.util.Observer;

import bfh.pm.test_hs15_2.Exchange;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

/**
 * The View Controller.
 *
 */
public class MainStageController implements Observer {

	@FXML
	private TextField tefi_operand1;

	@FXML
	private TextField tefi_operand2;

	@FXML
	private Label lb_operationSign;

	@FXML
	private Label lb_calcResult;

	@FXML
	private Button btn_plusOperation;

	@FXML
	private Button btn_minusOperation;

	@FXML
	private Button btn_multiplyOperation;

	@FXML
	private Button btn_divideOperation;

	@FXML
	private Label lb_changeCourse;

	@FXML
	private TextField tefi_euro;

	@FXML
	private Label lb_resultChangeCalc;

	@FXML
	private Button btn_calculateChange;

	@FXML
	private BorderPane bopa_below;

	private Exchange exchange;

	private double changeCourse;

	@FXML
	public void initialize() {
		// setting the css id to get the black border through css
		bopa_below.setId("bopa_below");
	}

	public void init(Exchange exchange) {
		this.exchange = exchange;

		exchange.addObserver(this);
	}

	@FXML
	private void pressed_btn_plusOperation() {
		lb_operationSign.setText("+");

		int operand1 = Integer.parseInt(tefi_operand1.getText());
		int operand2 = Integer.parseInt(tefi_operand2.getText());
		int result = operand1 + operand2;

		lb_calcResult.setText(Integer.toString(result));
	}

	@FXML
	private void pressed_btn_minusOperation() {

		lb_operationSign.setText("-");

		int operand1 = Integer.parseInt(tefi_operand1.getText());
		int operand2 = Integer.parseInt(tefi_operand2.getText());
		int result = operand1 - operand2;

		lb_calcResult.setText(Integer.toString(result));
	}

	@FXML
	private void pressed_btn_multiplyOperation() {

		lb_operationSign.setText("*");

		int operand1 = Integer.parseInt(tefi_operand1.getText());
		int operand2 = Integer.parseInt(tefi_operand2.getText());
		int result = operand1 * operand2;

		lb_calcResult.setText(Integer.toString(result));
	}

	@FXML
	private void pressed_btn_divideOperation() {

		lb_operationSign.setText("/");

		int operand1 = Integer.parseInt(tefi_operand1.getText());
		int operand2 = Integer.parseInt(tefi_operand2.getText());
		int result = operand1 / operand2;

		lb_calcResult.setText(Integer.toString(result));
	}

	@FXML
	private void pressed_btn_calculateChange() {
		double result = changeCourse * Double.parseDouble(tefi_euro.getText());

		lb_resultChangeCalc.setText(Double.toString(result));
	}

	@Override
	public void update(Observable o, Object arg) {
		this.changeCourse = exchange.getRate();

		Platform.runLater(() -> {
			lb_changeCourse.setText(Double.toString(this.changeCourse));
		});
	}

}
