package bfh.test;

import java.io.IOException;

import bfh.pm.test_hs15_2.Exchange;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * The one and only stage.
 *
 */
public class MainStage extends Stage {

	private Exchange exchange;

	public MainStage(Exchange exchange) throws IOException {
		this.exchange = exchange;

		FXMLLoader loader = new FXMLLoader(getClass().getResource("MainStage.fxml"));

		Parent parent = loader.load();

		loader.<MainStageController> getController().init(exchange);

		Scene scene = new Scene(parent);

		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

		this.setScene(scene);
		this.setTitle("Test HS15");
		this.show();
	}
}
