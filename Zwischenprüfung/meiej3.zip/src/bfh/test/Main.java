package bfh.test;

import bfh.pm.test_hs15_2.Exchange;
import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		Exchange exchange = new Exchange();

		new MainStage(exchange);
	}

	public static void main(String[] args) {
		launch(args);
	}

}
